parrot = "Bangladesh Blue"
print(parrot)
print(parrot[1])
print(parrot[-3])
print(parrot[0:6])
print(parrot[6:1])
print(parrot[-4:-2])
print(parrot[6:1:-2])

number = "9.22 , 36.0 , 4,9,"
print(number[1::4])
numbers = "1,2,3,4,5,6,7,8,9"
print(numbers[0::3])
string1 = "he 's  "
string2 = " probbaly "
print(string1 + string2)
print("HELLO " * 5)
print("hello " *(5+4))
today = "friday"
print("day" in today)
print("fri" in today)
print("thur" in today)
print("parrot " in "fdj")


age = 21
print("My age is " +str(age)+ " years" )
print("My age is {0} Years".format(age))
print("There are {0} days in {1}, {2},{3},{4},{5},{6} and {7} ".format(31,"january", "march", "april", "june ","july",
                                                                      " october","december"))
print(""""january: {2}
Ferbruary:{0}
March:{2}
April:{1}
May:{2}
June:{1}
July:{2}
Aguest:{2}
September:{1}
October:{2}
November:{1}
December:{2}""".format(28,30,31))
print("My Name is %d years" %age)
print("My Name is %d %s %d %s " %(age, " years " , 6, "months"))
for i in range(1,12):
    print("No. %2d squared is %4d and cubed is %4d" %(i,i**2,i**3))

    print("pi is approximately %12.50f" %(22/7))

    for i in range(1,12):
        print("No.{0:2} squared is {1:<4} and cubed  is  {2:<4}".format(i,i**2,i**3))
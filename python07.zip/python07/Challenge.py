# import time
#
# print("time():\t\t\t", time.get_clock_info('time'))
# print("perf_counter():\t",time.get_clock_info('perf_counter'))
# print("monotonic():\t",time.get_clock_info('monotonic'))
# print("process_time():t",time.get_clock_info('process_time'))

# import time
#
# print("The epoch on this system starts at " +time.strftime('%c',time.gmtime(0)))
# print("The current timezone is {0} with an offset of {1}".format(time.tzname[0],time.timezone))
# if time.daylight !=0:
#     print("\tDaylight saving time is in effect for this location")
#     print("\tThe DST timezone is"+time.tzname[1])
#
# print("Local time is " +time.strftime('%Y-%m-%d %H:%M:%S',time.localtime()))
# print("UTC time is " +time.strftime('%Y-%m-%d %H:%M:%S',time.gmtime()))

import pytz

country = 'Europe/Moscow'
tz_to_display = pytz.timezone(country)
local_time = datetime.datetime.now(tz = tz_to_display)
print("The time in {} is {}".format(country, local_time))
print("UTC is {}".format(datetime.datetime.utcnow()))

# for x in pytz.all_timezones:
#     print(x)
#
# for x in sorted(pytz.country_names):
#     print(x + ":" + pytz.country_names[x])
#
# for x in sorted(pytz.country_names):
#     print("{}: {}: {}".format(x, pytz.country_names[x], pytz.country_timezones.get(x)))

for x in sorted(pytz.country_names):
    print("{}: {}".format(x, pytz.country_names[x]) ,end= '')
    if x in pytz.country_timezones:
        for zone in sorted(pytz.country_timezones[x]):
            tz_to_display = pytz.timezone(zone)
            local_time = datetime.datetime.now(tz = tz_to_display)
            print("\t\t{}: {}".format(zone, local_time))
    else:
        print("\t\tNo time zone defined")


import datetime
import pytz
local_time = datetime.datetime.now()
utc_time = datetime.datetime.now()

print("Naive local time{}".format(local_time))
print("Naive UTC time{}".format(utc_time))

aware_local_time = pytz.utc.localize(local_time)
aware_utc_time = pytz.utc.localize(utc_time)

print("Aware local time{}, time zone {}".format(aware_local_time,aware_local_time.tzinfo))
print("Aware UTC {}, time zone{}".format(aware_utc_time,aware_utc_time.tzinfo))
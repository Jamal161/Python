# print(dir())
# for m in dir(__builtins__):
#     print(m)

# import shelve

# print(dir())
# print()
# print(dir(shelve))
# import shelve

# for obj in dir(shelve.Shelf):
#     if obj[0] != '_':
#         print(obj)
# help(shelve)

# import random
# help(random.randint)

# import webbrowser
# # webbrowser.open("https://www.youtube.com")
# help(webbrowser)

# for i in range(10):
#     print(1,2,3,4,5,6,7,8,9, sep='; ', end = ' ')

# import time
#
# print(time.gmtime(0))
# # print(time.localtime())
# # print(time.time())
#
# time_here = time.localtime()
# print(time_here)
# print("Year", time_here[0],time_here.tm_year)
# print("Months",time_here[1],time_here.tm_mon)
# print("Day",time_here[2],time_here.tm_mday)


# import time
# from time import time as  my_timer
# import random
#
# input("Press enter to start ")
# wait_time = random.randint(1,6)
# time.sleep(wait_time)
# start_time = my_timer()
# input("Press enter to stop")
#
# end_time = my_timer()
#
# print("Start at " + time.strftime("%X",time.localtime(start_time)))
# print("Ended at "+time.strftime("%X",time.localtime(end_time)))
#
# print("Your reaction time wsa {} seconds".format(start_time - end_time))





# done = "well done ,you have finished your drawing"
#
# from turtle import *
#
#
# forward(150)
# right(250)
# forward(150)
# circle(75)
#
# done()
# print(done)

print(dir())
print(dir('_builtins_'))

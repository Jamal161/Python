import random

deck = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 10, 10]
number_of_decks = 4

# define function to define the cards

def cards_define_function():
    cards = deck * number_of_decks
    return cards

# define the cards

cards = cards_define_function()

# define function remove card

def remove_card(string):
    return cards.remove(string)

# define a function for computer cards

def computer_cards():
    computer_card_one = random.choice(cards)
    remove_card(computer_card_one)
    computer_card_two = random.choice(cards)
    remove_card(computer_card_two)
    computer_total = computer_card_one + computer_card_two
    return computer_card_one, computer_card_two, computer_total

# define a function for user's initial cards

def user_cards():
    user_card_one = random.choice(cards)
    remove_card(user_card_one)
    user_card_two = random.choice(cards)
    remove_card(user_card_two)
    user_total = user_card_one + user_card_two
    return user_card_one, user_card_two, user_total

# define a single random card function

def one_more_card():
    extra_card = random.choice(cards)
    remove_card(extra_card)
    return extra_card

# define computer random card function

def computer_new_random_card():
    computer_new_card = random.choice(cards)
    remove_card(computer_new_card)
    return computer_new_card

# define cards lists (user and computer)

computer_cards = list(computer_cards())
user_cards = list(user_cards())

# define computer stands on

computer_stands_on = 17

# define the showing functions

def computer_show():
    print("Computer has {}".format(computer_cards))

def user_show():
    print("You have {}".format(user_cards))

def bust():
    print("BUST! You lost, that was easy money for the Computer!")

def ask_again():
     new_answer = input("Computer stands on {}. Do you want another card? ".format(computer_stands_on))
     return new_answer



# define function to ask user (main function)

def ask_user_initial():
    answer = input("Your first card is {}, computer's first card is {}, type 'SHOW' to show your other card! "
        .format(user_cards[0], computer_cards[0]))
    if answer != '':
        user_show()
    while user_cards[len(user_cards)-1] <= 21:
        new_answer = ask_again()
        if new_answer == 'yes' or new_answer == 'YES':
            extra_card = one_more_card()
            user_cards[len(user_cards)-1] += extra_card
            print("Your new card is a {}!".format(extra_card))
            print("Your new total is {}".format(user_cards[len(user_cards)-1]))
            user_cards.insert(len(user_cards)-1, extra_card)
        else:
            # case 1 while computer total < computer_stands_on -> draw card
                # computer has to draw its new card/cards
            while computer_cards[len(computer_cards)-1] < computer_stands_on:
                computer_new_card = computer_new_random_card()
                print("Computer has drawn {}".format(computer_new_card))
                computer_cards[len(computer_cards)-1] += computer_new_card
                computer_cards.insert(len(computer_cards)-1, computer_new_card)

            # case 2 else show user's and computer's results
            else:
                if computer_cards[len(computer_cards)-1] <= 21:
                    if computer_cards[len(computer_cards)-1] < user_cards[len(user_cards)-1]:
                        print("Your total is {}".format(user_cards[len(user_cards)-1]))
                        user_show()
                        print("Computer has {}".format(computer_cards))
                        print("CONGRATS, it looks like you won this one! Let's play again!")
                        break
                    elif computer_cards[len(computer_cards)-1] > user_cards[len(user_cards)-1]:
                        print("Your total is {}".format(user_cards[len(user_cards)-1]))
                        user_show()
                        print("Computer has {}".format(computer_cards))
                        print("OOOOPS, You should have asked for ANOTHER card, computer wins AGAIN!")
                        break
                    else:
                        print("Your total is {}".format(user_cards[len(user_cards)-1]))
                        print("Computer has {}".format(computer_cards))
                        print("This is a PUSH, it was a nice hand both of you played great!")
                        break
                else:
                    print("Your total is {}".format(user_cards[len(user_cards)-1]))
                    user_show()
                    print("Computer has {}".format(computer_cards))
                    print("CONGRATS, it looks like you won this one! Let's play again!")
                    break

    else:
        bust()
        user_show()
        while computer_cards[len(computer_cards)-1] < computer_stands_on:
            computer_new_card = computer_new_random_card()
            print("Computer has drawn {}".format(computer_new_card))
            computer_cards[len(computer_cards)-1] += computer_new_card
            computer_cards.insert(len(computer_cards)-1, computer_new_card)
        computer_show()


ask_user_initial()

